package ch05.sec06;

public class ArrayCreateByNewExample {
    public static void main(String[] args) {
        int [] arr1 = new int [3];
        String [] arr2 = new String [3];

        System.out.println(arr1);
        System.out.println(arr2);


    }
}
