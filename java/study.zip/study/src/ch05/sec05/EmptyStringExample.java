package ch05.sec05;

public class EmptyStringExample {
    public static void main(String[] args) {
        String hobby = "";

        if ( hobby.equals("") ) {
            System.out.println("Hobby은 빈 문자열");
        }
    }
}
