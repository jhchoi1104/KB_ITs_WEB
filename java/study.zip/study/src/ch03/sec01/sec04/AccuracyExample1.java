package ch03.sec01.sec04;

public class AccuracyExample1 {
    public static void main(String[] args) {
        int apple =1;
        double pieceUnit = 0.1;
        int number = 7;

        double result = apple - number * pieceUnit;
        System.out.println(result);
    }
}
