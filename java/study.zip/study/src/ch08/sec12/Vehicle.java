package ch08.sec12;

public interface Vehicle {
    void run();
}
