package org.scoula.lib.cli.command;

public interface Command {
    void execute();
}
