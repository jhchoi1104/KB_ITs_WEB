package ch04.sec02;

public class IfElseExample {
    public static void main(String[] args) {
        int score = 85;

        if (score >= 90) {
            System.out.println("Your score is A");
        } else {
            System.out.println("Your score is B");
        }
    }
}
