package ch16.sec01;

public interface Calculable {
    void calculate(int x, int y);
}
