package ch07.sec10.exam02;

public abstract class Animal {
    public void breathe() {
        System.out.println("숨을 쉽니다.");
    }
    public void sound() {
        System.out.println("소리를 냅니다.");
    }
}
