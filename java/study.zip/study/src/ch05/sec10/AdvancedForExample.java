package ch05.sec10;

public class AdvancedForExample {
    public static void main(String[] args) {
        int [] scores = { 95, 71, 84, 93, 87};

        for ( int score : scores) {
            System.out.println(score);
        }
    }
}
