package ch07.exam;

public abstract class HttpServlet {
    public abstract void service();
}
