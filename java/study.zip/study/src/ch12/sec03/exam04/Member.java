package ch12.sec03.exam04;

public record Member(String id, String name, int age) {

}
