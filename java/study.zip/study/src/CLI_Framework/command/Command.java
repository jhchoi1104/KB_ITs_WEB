package CLI_Framework.command;

public interface Command {
    void execute();
}
