package org.scoula.lib.cli.command;

public interface Command {
    public void execute();
}
