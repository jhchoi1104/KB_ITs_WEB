package ch03.sec01.sec04;

public class AccuracyExample2 {
    public static void main(String[] args) {
        int apple = 1;
        int totalPieces = apple*10;
        int number = 7;

        int result = totalPieces - number;
        System.out.println(result);
        System.out.println(result/10.0);
    }
}
