package ch05.sec05;

public class IndexOfContainsExample {
    public static void main(String[] args) {
        String subject = "자바 프로그래밍";

        int index = subject.indexOf("프로그래밍");
        System.out.println(index);


    }
}
