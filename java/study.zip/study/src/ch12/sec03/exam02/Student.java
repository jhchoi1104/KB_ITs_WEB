package ch12.sec03.exam02;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Student {
    private int no;
    private String name;
}
