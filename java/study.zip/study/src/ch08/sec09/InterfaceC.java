package ch08.sec09;

public interface InterfaceC extends InterfaceA, InterfaceB {
    void methodC();
}
