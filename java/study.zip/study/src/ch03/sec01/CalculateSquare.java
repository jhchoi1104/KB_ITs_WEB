package ch03.sec01;

public class CalculateSquare {
    public static void main(String[] args) {
//        int x=5;
//        double y=10.0;
//        int z=7;
//
//        double result = (x+z)/2.0*y;
//        System.out.println(result);

        int x = 10;
        int y=5;
        System.out.println((x>7)&&(y<=5));
        System.out.println((x%3 == 2)||(y%2 !=1));
    }
}
