package ch07.sec03.exam02;

public class SmartPhoneExample {
    public static void main(String[] args) {
        SmartPhone mySmartPhone = new SmartPhone("삼성", "블랙");

    }
}
