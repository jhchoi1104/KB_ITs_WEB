package ch08.sec09;

public interface InterfaceA {
    void methodA();
}
