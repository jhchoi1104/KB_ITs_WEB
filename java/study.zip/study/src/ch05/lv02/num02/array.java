package ch05.lv02.num02;

public class array {
    public static void main(String[] args) {
        int[] array = {1,5,3,8,2};

        for (int item : array ) {
            System.out.println(item);
        }
    }
}
