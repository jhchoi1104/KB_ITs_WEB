package ch04.sec02;

public class IfDiceExample {
    public static void main(String[] args) {
        int num = ((int) (Math.random()*5)+1);
        System.out.println(num);
    }
}
