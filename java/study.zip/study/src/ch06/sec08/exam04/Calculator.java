package ch06.sec08.exam04;

public class Calculator {
    double areaRectangle(double width) {
        return width * width;
    }
    double areaRectangle(double width, double height) {
        return width * height;
    }
}
